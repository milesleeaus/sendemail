module.exports = {
    SENDGRID_API: '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',
    MAILGUN_API: '0478686ee1d29fbdc3fc3017c966d1ff-4a62b8e8-0a2c9f08'
}